import TrendChart from "./TrendChart";

function formatINR(n) {
  return "₹" + Math.round(n).toLocaleString("en-IN");
}

export default function Receipt({ summary, narrative, onRefresh, refreshing }) {
  const { totals, period_covered, weekly_revenue_trend, last_14_days_breakdown, anomalies } = summary;
  const topBreakdown = last_14_days_breakdown.slice(0, 5);
  const genDate = new Date(summary.generated_at);

  return (
    <div className="receipt-wrap">
      <div className="desk-label">n8n → analysis.py → claude api → this receipt</div>

      <div className="receipt">
        <div className="receipt-header">
          <div className="masthead">AutoInsight</div>
          <div className="sub">
            Weekly Sales Report · {period_covered.start} → {period_covered.end}
          </div>
          <div className="sub">Printed {genDate.toLocaleDateString()} {genDate.toLocaleTimeString()}</div>
        </div>

        <hr className="rule" />

        <div className="line-item">
          <span className="label">Total revenue</span>
          <span className="value">{formatINR(totals.revenue)}</span>
        </div>
        <div className="line-item">
          <span className="label">Units sold</span>
          <span className="value">{totals.units_sold.toLocaleString("en-IN")}</span>
        </div>
        <div className="line-item">
          <span className="label">Returns</span>
          <span className="value">{totals.returns.toLocaleString("en-IN")}</span>
        </div>

        <hr className="rule" />

        <div className="section-title">Revenue trend</div>
        <TrendChart data={weekly_revenue_trend} />

        <hr className="rule" />

        <div className="section-title">Top regions · last 14 days</div>
        {topBreakdown.map((b, i) => (
          <div className="line-item" key={i}>
            <span className="label">{b.region} · {b.category}</span>
            <span className="value">{formatINR(b.revenue)}</span>
          </div>
        ))}

        <hr className="rule" />

        <div className="section-title">Anomalies flagged ({anomalies.length})</div>
        {anomalies.slice(0, 4).map((a, i) => (
          <div className={`anomaly-row ${a.direction}`} key={i}>
            <div>
              <div style={{ fontWeight: 700 }}>{a.region} · {a.category}</div>
              <div style={{ color: "#5c5646", fontSize: 11 }}>
                {a.date} · {a.units_sold} units (baseline {a.baseline_avg})
              </div>
            </div>
            <span className={`stamp ${a.direction}`}>
              {a.direction === "spike" ? "SPIKE" : "DIP"}
            </span>
          </div>
        ))}

        <hr className="rule" />

        <div className="section-title">Claude's read on it</div>
        <div className="narrative-block">{narrative}</div>

        <div className="footer-barcode" />
        <div className="footer-note">GENERATED AUTOMATICALLY · NO HUMAN TOUCHED THIS REPORT</div>
      </div>

      <button className="refresh-btn" onClick={onRefresh} disabled={refreshing}>
        {refreshing ? "Refreshing…" : "↻ Re-run pipeline (live backend)"}
      </button>
    </div>
  );
}
