import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div
      style={{
        background: "#262117",
        color: "#ede6d2",
        fontFamily: "JetBrains Mono, monospace",
        fontSize: 11,
        padding: "6px 10px",
        borderRadius: 3,
      }}
    >
      Week {label}: ₹{payload[0].value.toLocaleString("en-IN")}
    </div>
  );
}

export default function TrendChart({ data }) {
  return (
    <div className="chart-box">
      <ResponsiveContainer width="100%" height={110}>
        <LineChart data={data} margin={{ top: 4, right: 6, left: 6, bottom: 0 }}>
          <XAxis
            dataKey="week"
            tick={{ fontSize: 9, fill: "#5c5646", fontFamily: "JetBrains Mono" }}
            axisLine={{ stroke: "#c7bd9e" }}
            tickLine={false}
            interval="preserveStartEnd"
          />
          <YAxis hide domain={["dataMin - 500000", "dataMax + 500000"]} />
          <Tooltip content={<CustomTooltip />} />
          <Line
            type="linear"
            dataKey="revenue"
            stroke="#262117"
            strokeWidth={1.5}
            dot={{ r: 2, fill: "#262117" }}
            activeDot={{ r: 4 }}
            isAnimationActive={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
