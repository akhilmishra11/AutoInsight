import { useEffect, useState } from "react";
import Receipt from "./components/Receipt";
import { fallbackSummary, fallbackNarrative } from "./data/fallbackData";

// Point this at your deployed FastAPI backend (e.g. Render URL) to go live.
// Leave as-is to run the dashboard standalone off the bundled sample data.
const API_BASE = import.meta.env.VITE_API_BASE || "";

export default function App() {
  const [summary, setSummary] = useState(fallbackSummary);
  const [narrative, setNarrative] = useState(fallbackNarrative.narrative);
  const [refreshing, setRefreshing] = useState(false);
  const [liveMode, setLiveMode] = useState(false);

  useEffect(() => {
    if (!API_BASE) return;
    fetch(`${API_BASE}/api/summary`)
      .then((r) => r.json())
      .then((data) => {
        setSummary(data);
        setLiveMode(true);
      })
      .catch(() => {
        /* silently keep fallback data — backend not running */
      });

    fetch(`${API_BASE}/api/narrative`)
      .then((r) => r.json())
      .then((data) => setNarrative(data.narrative))
      .catch(() => {});
  }, []);

  const handleRefresh = async () => {
    if (!API_BASE) {
      alert("Set VITE_API_BASE to your FastAPI backend URL to enable live refresh.");
      return;
    }
    setRefreshing(true);
    try {
      const res = await fetch(`${API_BASE}/api/refresh`, { method: "POST" });
      const data = await res.json();
      setSummary(data.summary);
      setNarrative(data.narrative.narrative);
    } catch (e) {
      alert("Refresh failed — is the backend running?");
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <Receipt
      summary={summary}
      narrative={narrative}
      onRefresh={handleRefresh}
      refreshing={refreshing}
    />
  );
}
