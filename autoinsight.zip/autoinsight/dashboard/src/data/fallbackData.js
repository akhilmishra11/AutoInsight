// Static snapshot bundled so the dashboard renders standalone (e.g. on Vercel)
// without the FastAPI backend running. Point USE_LIVE_API at your backend to go live.
export const fallbackSummary = {
  "generated_at": "2026-09-04T06:03:28.822564",
  "period_covered": {
    "start": "2026-05-08",
    "end": "2026-09-04"
  },
  "totals": {
    "revenue": 105300332.64,
    "units_sold": 74045,
    "returns": 1467
  },
  "weekly_revenue_trend": [
    {
      "week": 19,
      "revenue": 2969957.58
    },
    {
      "week": 20,
      "revenue": 6082603.08
    },
    {
      "week": 21,
      "revenue": 6195061.36
    },
    {
      "week": 22,
      "revenue": 5991474.58
    },
    {
      "week": 23,
      "revenue": 6215613.53
    },
    {
      "week": 24,
      "revenue": 6308139.86
    },
    {
      "week": 25,
      "revenue": 6030441.73
    },
    {
      "week": 26,
      "revenue": 6379435.83
    },
    {
      "week": 27,
      "revenue": 6356843.59
    },
    {
      "week": 28,
      "revenue": 6272077.02
    },
    {
      "week": 29,
      "revenue": 6744400.28
    },
    {
      "week": 30,
      "revenue": 6591143.27
    },
    {
      "week": 31,
      "revenue": 6089031.43
    },
    {
      "week": 32,
      "revenue": 5845745.2
    },
    {
      "week": 33,
      "revenue": 5217776.67
    },
    {
      "week": 34,
      "revenue": 6072947.57
    },
    {
      "week": 35,
      "revenue": 6037853.88
    },
    {
      "week": 36,
      "revenue": 3899786.18
    }
  ],
  "last_14_days_breakdown": [
    {
      "region": "North",
      "category": "Electronics",
      "revenue": 1117778.72,
      "units": 611,
      "returns": 11,
      "return_rate_pct": 1.8
    },
    {
      "region": "South",
      "category": "Electronics",
      "revenue": 1053617.83,
      "units": 590,
      "returns": 8,
      "return_rate_pct": 1.36
    },
    {
      "region": "North",
      "category": "Fashion",
      "revenue": 1010209.65,
      "units": 643,
      "returns": 15,
      "return_rate_pct": 2.33
    },
    {
      "region": "West",
      "category": "Electronics",
      "revenue": 948309.63,
      "units": 535,
      "returns": 10,
      "return_rate_pct": 1.87
    },
    {
      "region": "South",
      "category": "Fashion",
      "revenue": 943231.34,
      "units": 583,
      "returns": 12,
      "return_rate_pct": 2.06
    },
    {
      "region": "West",
      "category": "Fashion",
      "revenue": 887746.01,
      "units": 545,
      "returns": 10,
      "return_rate_pct": 1.83
    },
    {
      "region": "North",
      "category": "Beauty",
      "revenue": 868749.4,
      "units": 733,
      "returns": 23,
      "return_rate_pct": 3.14
    },
    {
      "region": "East",
      "category": "Electronics",
      "revenue": 823416.59,
      "units": 461,
      "returns": 7,
      "return_rate_pct": 1.52
    },
    {
      "region": "East",
      "category": "Fashion",
      "revenue": 795357.35,
      "units": 505,
      "returns": 9,
      "return_rate_pct": 1.78
    },
    {
      "region": "North",
      "category": "Home",
      "revenue": 689616.25,
      "units": 645,
      "returns": 14,
      "return_rate_pct": 2.17
    },
    {
      "region": "West",
      "category": "Beauty",
      "revenue": 665135.72,
      "units": 570,
      "returns": 8,
      "return_rate_pct": 1.4
    },
    {
      "region": "South",
      "category": "Home",
      "revenue": 643755.97,
      "units": 607,
      "returns": 15,
      "return_rate_pct": 2.47
    },
    {
      "region": "South",
      "category": "Beauty",
      "revenue": 634265.28,
      "units": 560,
      "returns": 9,
      "return_rate_pct": 1.61
    },
    {
      "region": "East",
      "category": "Home",
      "revenue": 584511.42,
      "units": 540,
      "returns": 7,
      "return_rate_pct": 1.3
    },
    {
      "region": "East",
      "category": "Beauty",
      "revenue": 579798.96,
      "units": 479,
      "returns": 5,
      "return_rate_pct": 1.04
    },
    {
      "region": "West",
      "category": "Home",
      "revenue": 543322.67,
      "units": 497,
      "returns": 6,
      "return_rate_pct": 1.21
    }
  ],
  "anomalies": [
    {
      "date": "2026-07-19",
      "region": "North",
      "category": "Electronics",
      "units_sold": 224,
      "baseline_avg": 50.5,
      "z_score": 6.27,
      "direction": "spike"
    },
    {
      "date": "2026-07-18",
      "region": "North",
      "category": "Electronics",
      "units_sold": 196,
      "baseline_avg": 50.5,
      "z_score": 5.26,
      "direction": "spike"
    },
    {
      "date": "2026-07-20",
      "region": "North",
      "category": "Electronics",
      "units_sold": 173,
      "baseline_avg": 50.5,
      "z_score": 4.43,
      "direction": "spike"
    },
    {
      "date": "2026-07-18",
      "region": "West",
      "category": "Home",
      "units_sold": 67,
      "baseline_avg": 36.6,
      "z_score": 3.89,
      "direction": "spike"
    },
    {
      "date": "2026-06-07",
      "region": "East",
      "category": "Home",
      "units_sold": 58,
      "baseline_avg": 33.2,
      "z_score": 3.3,
      "direction": "spike"
    },
    {
      "date": "2026-07-21",
      "region": "North",
      "category": "Electronics",
      "units_sold": 141,
      "baseline_avg": 50.5,
      "z_score": 3.27,
      "direction": "spike"
    },
    {
      "date": "2026-08-09",
      "region": "South",
      "category": "Fashion",
      "units_sold": 69,
      "baseline_avg": 37.3,
      "z_score": 3.11,
      "direction": "spike"
    },
    {
      "date": "2026-07-26",
      "region": "East",
      "category": "Electronics",
      "units_sold": 58,
      "baseline_avg": 34.0,
      "z_score": 3.1,
      "direction": "spike"
    },
    {
      "date": "2026-08-22",
      "region": "South",
      "category": "Electronics",
      "units_sold": 68,
      "baseline_avg": 38.2,
      "z_score": 3.0,
      "direction": "spike"
    },
    {
      "date": "2026-08-11",
      "region": "South",
      "category": "Electronics",
      "units_sold": 9,
      "baseline_avg": 38.2,
      "z_score": -2.94,
      "direction": "dip"
    },
    {
      "date": "2026-08-14",
      "region": "South",
      "category": "Electronics",
      "units_sold": 9,
      "baseline_avg": 38.2,
      "z_score": -2.94,
      "direction": "dip"
    },
    {
      "date": "2026-08-12",
      "region": "South",
      "category": "Beauty",
      "units_sold": 11,
      "baseline_avg": 37.2,
      "z_score": -2.83,
      "direction": "dip"
    },
    {
      "date": "2026-08-02",
      "region": "North",
      "category": "Home",
      "units_sold": 76,
      "baseline_avg": 45.4,
      "z_score": 2.78,
      "direction": "spike"
    },
    {
      "date": "2026-05-10",
      "region": "North",
      "category": "Beauty",
      "units_sold": 74,
      "baseline_avg": 45.2,
      "z_score": 2.78,
      "direction": "spike"
    },
    {
      "date": "2026-05-17",
      "region": "North",
      "category": "Fashion",
      "units_sold": 71,
      "baseline_avg": 45.1,
      "z_score": 2.77,
      "direction": "spike"
    }
  ]
};

export const fallbackNarrative = {
  "generated_at": "2026-09-04T06:03:28.822564",
  "narrative": "Over 2026-05-08 to 2026-09-04, total revenue reached \u20b9105,300,333 across 74,045 units sold, with a return count of 1,467.\n\nKey anomalies detected:\n- North / Electronics spiked to 224 units on 2026-07-19 (baseline ~50.5, z-score 6.27).\n- North / Electronics spiked to 196 units on 2026-07-18 (baseline ~50.5, z-score 5.26).\n- North / Electronics spiked to 173 units on 2026-07-20 (baseline ~50.5, z-score 4.43).\n- West / Home spiked to 67 units on 2026-07-18 (baseline ~36.6, z-score 3.89).\n\nRecommendation: investigate the largest spike for a possible promo or stockout-driven surge, and check the largest dip for a regional fulfillment or listing issue before it compounds next week."
};
