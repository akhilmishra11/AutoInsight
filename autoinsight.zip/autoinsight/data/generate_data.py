"""
generate_data.py
Creates a synthetic 120-day ecommerce sales dataset with a few
deliberately injected anomalies (a demand spike and a regional dip)
so the anomaly-detection step in analysis.py has something real to catch.
"""

import csv
import random
from datetime import date, timedelta

random.seed(42)

REGIONS = ["North", "South", "East", "West"]
CATEGORIES = {
    "Electronics": ["Wireless Earbuds", "Smart Watch", "Power Bank", "Bluetooth Speaker"],
    "Fashion": ["Sneakers", "Denim Jacket", "Backpack", "Sunglasses"],
    "Home": ["Table Lamp", "Coffee Maker", "Cushion Set", "Wall Clock"],
    "Beauty": ["Face Serum", "Lip Kit", "Hair Dryer", "Perfume"],
}

BASE_PRICE = {
    "Wireless Earbuds": 1499, "Smart Watch": 2999, "Power Bank": 899, "Bluetooth Speaker": 1799,
    "Sneakers": 2199, "Denim Jacket": 1899, "Backpack": 1299, "Sunglasses": 999,
    "Table Lamp": 799, "Coffee Maker": 2499, "Cushion Set": 599, "Wall Clock": 449,
    "Face Serum": 699, "Lip Kit": 499, "Hair Dryer": 1599, "Perfume": 1899,
}

REGION_WEIGHT = {"North": 1.15, "South": 1.0, "East": 0.85, "West": 0.95}

START_DATE = date.today() - timedelta(days=119)
ROWS = []

for day_offset in range(120):
    d = START_DATE + timedelta(days=day_offset)
    weekday_boost = 1.3 if d.weekday() in (5, 6) else 1.0  # weekend bump

    for region in REGIONS:
        for category, products in CATEGORIES.items():
            for product in products:
                base = random.uniform(4, 14)
                units = base * REGION_WEIGHT[region] * weekday_boost
                units *= random.uniform(0.7, 1.3)

                # --- Injected anomaly 1: Electronics demand spike, North, days 70-74 ---
                if category == "Electronics" and region == "North" and 70 <= day_offset <= 74:
                    units *= 3.4

                # --- Injected anomaly 2: South region sales dip, days 95-100 ---
                if region == "South" and 95 <= day_offset <= 100:
                    units *= 0.35

                units = max(0, round(units))
                price = BASE_PRICE[product]
                revenue = round(units * price * random.uniform(0.95, 1.05), 2)
                returns = round(units * random.uniform(0.01, 0.06))

                ROWS.append({
                    "date": d.isoformat(),
                    "region": region,
                    "category": category,
                    "product": product,
                    "units_sold": units,
                    "revenue": revenue,
                    "returns": returns,
                })

out_path = "/home/claude/autoinsight/data/ecommerce_sales.csv"
with open(out_path, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["date", "region", "category", "product", "units_sold", "revenue", "returns"])
    writer.writeheader()
    writer.writerows(ROWS)

print(f"Wrote {len(ROWS)} rows to {out_path}")
