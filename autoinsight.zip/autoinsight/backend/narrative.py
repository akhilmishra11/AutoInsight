"""
narrative.py — turns summary.json's numbers into a plain-English
business narrative using the Claude API.

Set ANTHROPIC_API_KEY as an environment variable to use the real API.
If it's missing, a rule-based fallback narrative is produced instead,
so the demo still runs end-to-end without a key.
"""

import json
import os

SUMMARY_PATH = "/home/claude/autoinsight/backend/output/summary.json"
NARRATIVE_PATH = "/home/claude/autoinsight/backend/output/narrative.json"

SYSTEM_PROMPT = """You are a business data analyst writing a short weekly
report for a non-technical ecommerce operations team. You'll be given a
JSON summary of sales data (totals, weekly trend, regional/category
breakdown, and detected anomalies).

Write:
1. A 2-3 sentence executive summary of overall performance.
2. A bullet list of the most important anomalies, explained in plain
   English (what happened, where, and roughly how big the deviation was).
3. One actionable recommendation.

Keep it under 180 words. No preamble, no markdown headers, just the
report text with a bullet list where noted."""


def call_claude(summary: dict) -> str:
    import anthropic  # pip install anthropic

    client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from env
    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=500,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": json.dumps(summary, indent=2)}],
    )
    return message.content[0].text


def rule_based_fallback(summary: dict) -> str:
    """No-API-key fallback so the pipeline still produces a readable report."""
    totals = summary["totals"]
    anomalies = summary["anomalies"][:4]

    lines = []
    lines.append(
        f"Over {summary['period_covered']['start']} to {summary['period_covered']['end']}, "
        f"total revenue reached ₹{totals['revenue']:,.0f} across {totals['units_sold']:,} units sold, "
        f"with a return count of {totals['returns']:,}."
    )
    lines.append("\nKey anomalies detected:")
    for a in anomalies:
        direction = "spiked" if a["direction"] == "spike" else "dropped"
        lines.append(
            f"- {a['region']} / {a['category']} {direction} to {a['units_sold']} units on {a['date']} "
            f"(baseline ~{a['baseline_avg']}, z-score {a['z_score']})."
        )
    lines.append(
        "\nRecommendation: investigate the largest spike for a possible promo or stockout-driven "
        "surge, and check the largest dip for a regional fulfillment or listing issue before it "
        "compounds next week."
    )
    return "\n".join(lines)


def generate_narrative():
    with open(SUMMARY_PATH) as f:
        summary = json.load(f)

    if os.environ.get("ANTHROPIC_API_KEY"):
        try:
            text = call_claude(summary)
        except Exception as e:
            text = f"[Claude API call failed: {e}]\n\n" + rule_based_fallback(summary)
    else:
        text = rule_based_fallback(summary)

    result = {"generated_at": summary["generated_at"], "narrative": text}
    with open(NARRATIVE_PATH, "w") as f:
        json.dump(result, f, indent=2)

    print(text)
    return result


if __name__ == "__main__":
    generate_narrative()
