"""
analysis.py — AutoInsight core engine

Reads the raw sales CSV, produces:
  1. Weekly revenue trend (overall + by region)
  2. Category/region breakdown for the latest period
  3. Anomalies: days where a region/category's units_sold deviates
     sharply (z-score) from its own rolling baseline
  4. A structured summary.json that gets handed to Claude for the
     plain-English narrative (see narrative.py)

This exact logic is what sits inside the n8n "Analyze Data" Code node —
kept here as a standalone, testable module so you're not debugging
Python inside n8n's editor.
"""

import csv
import json
import statistics
from collections import defaultdict
from datetime import datetime

CSV_PATH = "/home/claude/autoinsight/data/ecommerce_sales.csv"
OUT_PATH = "/home/claude/autoinsight/backend/output/summary.json"

ANOMALY_Z_THRESHOLD = 2.2  # standard deviations from a region+category's own mean


def load_rows(path):
    with open(path) as f:
        reader = csv.DictReader(f)
        rows = []
        for r in reader:
            r["date"] = datetime.strptime(r["date"], "%Y-%m-%d").date()
            r["units_sold"] = float(r["units_sold"])
            r["revenue"] = float(r["revenue"])
            r["returns"] = int(r["returns"])
            rows.append(r)
    return rows


def weekly_revenue_trend(rows):
    weekly = defaultdict(float)
    for r in rows:
        week = r["date"].isocalendar()[1]
        weekly[week] += r["revenue"]
    weeks = sorted(weekly.keys())
    return [{"week": w, "revenue": round(weekly[w], 2)} for w in weeks]


def region_category_breakdown(rows, last_n_days=14):
    max_date = max(r["date"] for r in rows)
    cutoff = max_date.toordinal() - last_n_days

    breakdown = defaultdict(lambda: {"revenue": 0.0, "units": 0.0, "returns": 0})
    for r in rows:
        if r["date"].toordinal() < cutoff:
            continue
        key = (r["region"], r["category"])
        breakdown[key]["revenue"] += r["revenue"]
        breakdown[key]["units"] += r["units_sold"]
        breakdown[key]["returns"] += r["returns"]

    result = []
    for (region, category), vals in breakdown.items():
        result.append({
            "region": region,
            "category": category,
            "revenue": round(vals["revenue"], 2),
            "units": round(vals["units"]),
            "returns": vals["returns"],
            "return_rate_pct": round(100 * vals["returns"] / vals["units"], 2) if vals["units"] else 0,
        })
    return sorted(result, key=lambda x: -x["revenue"])


def detect_anomalies(rows):
    """
    For every (region, category) group, build a daily units_sold series,
    compute mean/stdev, and flag days that are ANOMALY_Z_THRESHOLD
    std-deviations away as a spike or dip.
    """
    grouped = defaultdict(list)
    for r in rows:
        grouped[(r["region"], r["category"])].append(r)

    anomalies = []
    for (region, category), group_rows in grouped.items():
        daily = defaultdict(float)
        for r in group_rows:
            daily[r["date"]] += r["units_sold"]

        values = list(daily.values())
        if len(values) < 5:
            continue
        mean = statistics.mean(values)
        stdev = statistics.pstdev(values) or 1e-6

        for d, v in daily.items():
            z = (v - mean) / stdev
            if abs(z) >= ANOMALY_Z_THRESHOLD:
                anomalies.append({
                    "date": d.isoformat(),
                    "region": region,
                    "category": category,
                    "units_sold": round(v),
                    "baseline_avg": round(mean, 1),
                    "z_score": round(z, 2),
                    "direction": "spike" if z > 0 else "dip",
                })

    return sorted(anomalies, key=lambda a: -abs(a["z_score"]))[:15]


def build_summary():
    rows = load_rows(CSV_PATH)

    summary = {
        "generated_at": datetime.now().isoformat(),
        "period_covered": {
            "start": min(r["date"] for r in rows).isoformat(),
            "end": max(r["date"] for r in rows).isoformat(),
        },
        "totals": {
            "revenue": round(sum(r["revenue"] for r in rows), 2),
            "units_sold": round(sum(r["units_sold"] for r in rows)),
            "returns": sum(r["returns"] for r in rows),
        },
        "weekly_revenue_trend": weekly_revenue_trend(rows),
        "last_14_days_breakdown": region_category_breakdown(rows, last_n_days=14),
        "anomalies": detect_anomalies(rows),
    }
    return summary


if __name__ == "__main__":
    import os
    os.makedirs("/home/claude/autoinsight/backend/output", exist_ok=True)
    summary = build_summary()
    with open(OUT_PATH, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"Summary written to {OUT_PATH}")
    print(f"Found {len(summary['anomalies'])} anomalies")
