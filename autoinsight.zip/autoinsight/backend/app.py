"""
app.py — FastAPI serving layer

Endpoints:
  GET  /api/summary     -> latest summary.json (revenue trend, breakdown, anomalies)
  GET  /api/narrative    -> latest narrative.json (Claude's plain-English report)
  POST /api/refresh      -> re-runs analysis.py + narrative.py (called by n8n
                             after it drops a fresh CSV, or hit manually)

Run: uvicorn app:app --reload --port 8000
"""

import json
import subprocess
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

BASE = Path(__file__).parent
OUTPUT = BASE / "output"

app = FastAPI(title="AutoInsight API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten to your dashboard's deployed URL in production
    allow_methods=["*"],
    allow_headers=["*"],
)


def _read_json(filename: str):
    path = OUTPUT / filename
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"{filename} not found — run /api/refresh first")
    with open(path) as f:
        return json.load(f)


@app.get("/api/summary")
def get_summary():
    return _read_json("summary.json")


@app.get("/api/narrative")
def get_narrative():
    return _read_json("narrative.json")


@app.post("/api/refresh")
def refresh():
    """Re-runs the pipeline. This is the endpoint n8n's HTTP Request node calls."""
    try:
        subprocess.run(["python3", str(BASE / "analysis.py")], check=True, cwd=BASE)
        subprocess.run(["python3", str(BASE / "narrative.py")], check=True, cwd=BASE)
    except subprocess.CalledProcessError as e:
        raise HTTPException(status_code=500, detail=str(e))

    return {
        "status": "refreshed",
        "summary": _read_json("summary.json"),
        "narrative": _read_json("narrative.json"),
    }


@app.get("/")
def health():
    return {"status": "ok", "service": "AutoInsight API"}
